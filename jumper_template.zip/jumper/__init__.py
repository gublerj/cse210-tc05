"""
The root package contains all the source code for the game.
"""